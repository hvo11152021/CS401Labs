package types;

import mechanics.CannotFly;
import mechanics.Duck;
import mechanics.Squeak;

public class RubberDuck implements Duck, CannotFly, Squeak {
	
}
