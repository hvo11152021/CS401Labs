package types;

import mechanics.CannotFly;
import mechanics.Duck;
import mechanics.MuteQuack;

public class DecoyDuck implements Duck, CannotFly, MuteQuack {
	
}
