package types;

import mechanics.Duck;

public class MallardDuck implements Duck {
	
}
