package types;

import mechanics.Duck;
import mechanics.MuteQuack;

public class RedheadDuck implements Duck, MuteQuack {
	
}
