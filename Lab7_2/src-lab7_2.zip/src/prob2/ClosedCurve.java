package prob2;

public interface ClosedCurve {	
	double computePerimeter();
}
